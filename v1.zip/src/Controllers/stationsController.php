<?php

namespace Ale\Bussescu\Controllers;

use Ale\Bussescu\Services\stationsService;

class stationsController
{
    private stationsService $service;

    public function __construct(stationsService $service)
    {
        $this->service = $service;
    }

    public function index() : void
    {
        header('Content-Type: application/json');
        $stations = $this->service->getAll();
        echo json_encode($stations);
    }
}

?>